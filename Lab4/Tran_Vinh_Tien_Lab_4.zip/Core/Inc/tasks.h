/*
 * tasks.h
 *
 *  Created on: Nov 16, 2021
 *      Author: Admin
 */

#ifndef INC_TASKS_H_
#define INC_TASKS_H_

void toggleRED();
void toggleGREEN();
void toggleBLUE();
void toggleYELL();
void togglePURPLE();

#endif /* INC_TASKS_H_ */
