/*
 * Led_matrix.h
 *
 *  Created on: Sep 27, 2021
 *      Author: LAPTOP MSI
 */
void updateAnimation (void);
void updateLEDMatrix (int index );
void displayCol (int col);
void displayRow (int row);
void clearAll(void);
void setupMatrix(void);
