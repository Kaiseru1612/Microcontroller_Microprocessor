/*
 * Digital_clock_display.h
 *
 *  Created on: Sep 20, 2021
 *      Author: LAPTOP MSI
 */

#define NUMBER_SEGMENT_1 	1
#define NUMBER_SEGMENT_2 	2
#define NUMBER_SEGMENT_3 	3
#define NUMBER_SEGMENT_4 	0
void runClock(int counter);
