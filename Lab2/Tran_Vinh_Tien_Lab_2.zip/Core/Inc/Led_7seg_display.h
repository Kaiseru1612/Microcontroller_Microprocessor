/*
 * Led_7seg_display.h
 *
 *  Created on: Sep 17, 2021
 *      Author: LAPTOP MSI
 */
#ifndef LED_7SEG_DISPLAY_H
#define LED_7SEG_DISPLAY_H
#define NUMBER_OF_SEGMENT	4


void seven_segment_led_driver(int index);
void update7SEG (int index );
#endif /*LED_7SEG_DISPLAY_H*/
