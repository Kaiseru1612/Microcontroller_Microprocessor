/*
 * Matrix_Display.h
 *
 *  Created on: Sep 18, 2021
 *      Author: LAPTOP MSI
 */

void testLed (void);
void clearAllClock(void);
void setNumberOnClock(int num);
void clearNumberOnClock(int num);
