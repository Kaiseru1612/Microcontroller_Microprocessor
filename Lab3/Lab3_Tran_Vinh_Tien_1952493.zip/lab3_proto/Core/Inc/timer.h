/*
 * timer.h
 *
 *  Created on: Oct 5, 2021
 *      Author: Admin
 */

#ifndef INC_TIMER_H_
#define INC_TIMER_H_

void HAL_TIM_PeriodElapsedCallback (TIM_HandleTypeDef* htim);

#endif /* INC_TIMER_H_ */
