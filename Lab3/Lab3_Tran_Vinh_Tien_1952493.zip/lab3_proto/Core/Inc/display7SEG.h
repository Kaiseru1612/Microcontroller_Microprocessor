/*
 * display7SEG.h
 *
 *  Created on: Nov 2, 2021
 *      Author: Admin
 */

#ifndef INC_DISPLAY7SEG_H_
#define INC_DISPLAY7SEG_H_

void turn_off_7seg(int disp_no);
void display7SEG(unsigned int disp_no, int var1);
void timerMode_run();
#endif /* INC_DISPLAY7SEG_H_ */
