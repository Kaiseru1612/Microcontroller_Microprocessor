/*
 * input_processing.h
 *
 *  Created on: Oct 4, 2021
 *      Author: Admin
 */

#ifndef INC_INPUT_PROCESSING_H_
#define INC_INPUT_PROCESSING_H_


void fsm_for_input_processing ();

#endif /* INC_INPUT_PROCESSING_H_ */
